var gulp = require('gulp');
var htmlClean = require('gulp-htmlclean');
var imageMin = require('gulp-imagemin');
var uglify = require('gulp-uglify');
var less = require('gulp-less');
var cssClean = require('gulp-clean-css');
var connect = require('gulp-connect');
var babel = require('gulp-babel');
var folder = {
    src:"src/",
    dist:"dist/"
}
gulp.task("html",function(cb){
    gulp.src(folder.src + "html/*")
        .pipe(connect.reload())
        .pipe(htmlClean())
        .pipe(gulp.dest(folder.dist + "html/"))  
        cb()     
});
gulp.task("css",function(cb){
    gulp.src(folder.src + "css/*")
        .pipe(less())
        .pipe(cssClean())
        .pipe(gulp.dest(folder.dist + "css/"))
        .pipe(connect.reload())
        cb()
});
gulp.task('server',function(cb){
    connect.server({
        port:'8888',
        livereload:true
    })
    cb()
})

gulp.task("image",function(cb){
    gulp.src(folder.src + "image/*")
        .pipe(imageMin())
        .pipe(gulp.dest(folder.dist + "image/"))
 
});
gulp.task("js",function(cb){
    gulp.src(folder.src + "js/*")
        .pipe(uglify())
        .pipe(gulp.dest(folder.dist + "js/"))
        .pipe(connect.reload())
        cb()
});

gulp.task("watch",function(cb){
    gulp.watch(folder.src + "html/*",gulp.series('html'))
    gulp.watch(folder.src + "css/*",gulp.series('css'))
    gulp.watch(folder.src + "js/*",gulp.series('js'))
    cb()
})

gulp.task("default",gulp.parallel('html','css','js','image','server','watch'));