(function($,root){
    var duration;
    var id;
//进度条模块，渲染左右时间 更新进度条
function renderAllTime(time){
    duration = time;
    time = formatTime(time);
    $('.all-time').text(time);
}
function formatTime(t){
    t = Math.round(t);
    var m = Math.floor(t / 60);
    var s = t - m * 60;
    if( m < 10){
        m = '0' + m;
    }
    if(s < 10){
        s = '0' + s;
    }
    return m + ':' + s;
}
function start(){
    function frame(){
        var curTime = audio.audio.currentTime;
        var per = curTime/duration;
        update(per);
        console.log(per);
        id = requestAnimationFrame(frame);
    }
    frame();
}
function stop(){
    cancelAnimationFrame(id)
}
//更新html
function update(p){
   var time = p * duration;
   time = formatTime(time);
   $('.cur-time').text(time);
   $('.pro-top').css('transform','translatex('+(p-1)*100+'%)');
}

root.pro = {
     renderAllTime:renderAllTime,
     start:start,
     update:update,
     stop:stop
}
})(window.Zepto,window.player || (window.player = {}))