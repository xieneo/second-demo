(function($,root){
    function Control(len){
        this.index = 0;
        this.len = len;
    }
    Control.prototype = {
        prev:function(){
            return this.getIndex(-1);
        },
        next:function(){
            return this.getIndex(1);
        },
        //计算改变后的索引
        getIndex:function(val){
            this.index = this.index + val;
            var len = this.len
            var curIndex = (this.index + len)%len;
            return curIndex;
        }
    }
    root.controlIndex = Control;
})(window.Zepto,window.player || (window.player = {}))