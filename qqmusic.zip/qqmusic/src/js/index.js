var root = window.player;
var dataList;
var len;
var audio = root.AudioManager;
var controlIndex;

function getData(url) {
    $.ajax({
        type: 'GET',
        url: url,
        success: function (data) {
            console.log(data);
            dataList = data;
            len = data.length;
            root.render(data[0]);
            root.pro.renderAllTime(data[0].duration);
            controlIndex = new root.controlIndex(len);
            audio.getAudio(data[0].audio);
            root.pro.start();
            root.pro.stop();
            bindEvent();
        },
        error: function () {
            console.log('error');
        }
    })
}
function bindEvent() {
    var left = $('.pro-bottom').offset().left;
    var width = $('.pro-bottom').width();
    var per;
    $('.prev').add('.next').on('click', function (e) {
        root.pro.stop();
        if (this.classList.contains('prev')) {
            var i = controlIndex.prev();
        } else {
            var i = controlIndex.next();
        }
        $('.img-box').css('animation', 'none');
        root.render(dataList[i]);
        audio.getAudio(dataList[i].audio);
        root.pro.renderAllTime(dataList[i].duration);
        if (audio.status == 'play') {
            audio.play();
            rotate('running');
        }
        root.pro.start();
    })
    $('.play').on('click', function () {
        if (audio.status == 'pause') {
            audio.play();
            root.pro.start();
            rotate('running');
        } else {
            audio.pause();
            rotate('paused');
            root.pro.stop();
        }
        $('.play').toggleClass('playing');
    })
    $('.slider').on('touchstart', function () {
        root.pro.stop();
    }).on('touchmove', function (e) {
        var x = e.touches[0].clientX;
        per = (x - left) / width;
        if (per >= 0 && per <= 1) {
            root.pro.update(per);
        }
    }).on('touchend', function () {
        if (per >= 0 && per <= 1) {
            audio.audio.currentTime = per * audio.audio.duration;
            if (audio.status == 'play') {
                audio.play();
                root.pro.start();
                rotate('running');
            }
        }
    })
    $('.like').on('click',function(){
        if(dataList[controlIndex.index].isLike){
            dataList[controlIndex.index].isLike = false;
        }else{
            dataList[controlIndex.index].isLike = true;
        }
        $(this).toggleClass('liking');
    })
}

function rotate(state) {
    $('.img-box').css('animation', 'rotate 5s linear infinite forwards ' + state);
}
getData("../mock/data.json")